bl_info = {
    "name": "Advanced AI Communication",
    "description": "Advanced AI chat interface with auto-monitoring and enhanced features",
    "author": "AI Assistant - Advanced Edition",
    "version": (2, 0, 0),
    "blender": (3, 2, 0),
    "location": "View3D > Sidebar > Advanced AI",
    "category": "3D View",
}

import bpy
import subprocess
import os
from pathlib import Path
import time
import json

# === PERSISTENT SETTINGS (editable variables) ===
DEFAULT_PATHS = {
    "niout_directory": "F:/odin_grab/a_astitnet/niout",
    "batch_file": "F:/odin_grab/a_astitnet/chat_with_portable_python.bat",
    "fallback_paths": [
        "F:/odin_grab/a_astitnet",
        "C:/Users/0-0/Desktop/Odin Grab/a_astitnet",
        "F:/odin_grab_1/odin_grab/a_astitnet"
    ]
}

UI_SETTINGS = {
    "default_panel_height": 15,  # Default number of response lines to show
    "max_panel_height": 50,     # Maximum lines
    "min_panel_height": 5,      # Minimum lines
    "default_model": "qwen3:8b",
    "auto_refresh_default": True
}

def save_settings_to_file(settings_dict, filename="advanced_ai_settings.json"):
    """Save settings to a JSON file in the addon directory"""
    try:
        addon_dir = Path(__file__).parent
        settings_file = addon_dir / filename
        with open(settings_file, 'w') as f:
            json.dump(settings_dict, f, indent=2)
        return True
    except Exception as e:
        print(f"Failed to save settings: {e}")
        return False

def load_settings_from_file(filename="advanced_ai_settings.json"):
    """Load settings from JSON file"""
    try:
        addon_dir = Path(__file__).parent
        settings_file = addon_dir / filename
        if settings_file.exists():
            with open(settings_file, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Failed to load settings: {e}")
    return {}

# Global monitoring functions (from Simple Chat)
def get_niout_directory():
    """Find the niout directory using Simple Chat's robust method"""
    current = Path(__file__).parent
    
    for parent in [current] + list(current.parents):
        if parent.name.lower() == 'odin_grab':
            niout_dir = parent / 'a_astitnet' / 'niout'
            if niout_dir.exists():
                return niout_dir
        elif parent.name == 'a_astitnet' and parent.parent.name.lower() == 'odin_grab':
            niout_dir = parent / 'niout'
            if niout_dir.exists():
                return niout_dir
    
    # Fallback
    return Path('F:/odin_grab/a_astitnet/niout')

def get_highest_response_number(niout_dir):
    """Get the highest numbered response file"""
    max_num = 0
    latest_file = None
    
    if niout_dir.exists():
        for file in niout_dir.glob('response_*.txt'):
            try:
                num_str = file.stem.replace('response_', '')
                num = int(num_str)
                if num > max_num:
                    max_num = num
                    latest_file = file
            except ValueError:
                continue
    
    return max_num, latest_file

def auto_refresh_monitor():
    """Monitor for new response files and auto-load them (from Simple Chat)"""
    try:
        import bpy
        props = bpy.context.window_manager.advanced_ai_props
        
        # Check if monitoring is enabled
        if not props.auto_refresh_enabled or not props.is_monitoring:
            props.monitoring_status = "Auto-refresh disabled"
            return None  # Stop timer
        
        niout_dir = get_niout_directory()
        current_max, latest_file = get_highest_response_number(niout_dir)
        
        # Check if we found a new file (higher number than we've seen)
        if current_max > props.last_known_max_number:
            # New file detected! Load it automatically
            props.last_known_max_number = current_max
            
            if latest_file and latest_file.exists():
                try:
                    # Load the new response
                    with open(latest_file, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                    
                    if content:
                        props.response = content
                        props.selected_response_file = latest_file.name
                        props.monitoring_status = f"📄 Auto-loaded {latest_file.name}"
                        
                        # Force UI update
                        for area in bpy.context.screen.areas:
                            if area.type == 'VIEW_3D':
                                area.tag_redraw()
                        
                        print(f"Advanced AI: Auto-loaded {latest_file.name}")
                        return 2.0  # Continue monitoring every 2 seconds
                    
                except Exception as e:
                    props.monitoring_status = f"Error loading {latest_file.name}: {e}"
                    print(f"Advanced AI Auto-Refresh Error: {e}")
        
        # Return 0 (no new files, continue watching)
        props.monitoring_status = f"👁️ Watching... (last: response_{current_max}.txt)" if current_max > 0 else "👁️ Watching..."
        return 2.0  # Continue monitoring every 2 seconds
        
    except Exception as e:
        print(f"Advanced AI Monitor Error: {e}")
        return None  # Stop on error

# Properties (Enhanced from both add-ons)
class AdvancedAIProps(bpy.types.PropertyGroup):
    """Advanced AI Chat Properties"""
    
    # Message input
    message: bpy.props.StringProperty(
        name="Message",
        description="Your message to AI",
        default="",
        maxlen=2000
    )
    
    # AI response - Increased maxlen for full responses
    response: bpy.props.StringProperty(
        name="Response",
        description="AI response",
        default="",
        maxlen=20000  # Much larger to show full responses
    )
    
    # File paths - auto-configured for odin_grab structure
    base_path: bpy.props.StringProperty(
        name="Base Path",
        description="Base path to odin_grab/a_astitnet directory",
        default="",
        subtype='DIR_PATH'
    )
    
    input_path: bpy.props.StringProperty(
        name="Input File",
        description="Path to input.txt file",
        default="",
        subtype='FILE_PATH'
    )
    
    output_path: bpy.props.StringProperty(
        name="Output File", 
        description="Path to response.txt file",
        default="",
        subtype='FILE_PATH'
    )
    
    ollama_script_path: bpy.props.StringProperty(
        name="Chat Script",
        description="Path to the chat script",
        default="",
        subtype='FILE_PATH'
    )
    
    # Model selection
    selected_model: bpy.props.StringProperty(
        name="Model",
        description="Selected AI model (e.g. qwen3:8b)",
        default="qwen3:8b"
    )
    
    # Options
    auto_run_ollama: bpy.props.BoolProperty(
        name="Auto Run",
        description="Automatically start chat process when sending message",
        default=True
    )
    
    use_versioned_responses: bpy.props.BoolProperty(
        name="Use Versioned Files",
        description="Monitor response_N.txt files for new responses",
        default=True
    )
    
    # Auto-refresh system (from Simple Chat)
    auto_refresh_enabled: bpy.props.BoolProperty(
        name="Auto Refresh",
        description="Automatically load new responses when they appear",
        default=True
    )
    
    # Internal monitoring state
    is_monitoring: bpy.props.BoolProperty(
        name="Is Monitoring",
        description="Currently monitoring for new responses",
        default=False
    )
    
    last_known_max_number: bpy.props.IntProperty(
        name="Last Known Max Number",
        description="Highest response number we've seen",
        default=0
    )
    
    monitoring_status: bpy.props.StringProperty(
        name="Monitoring Status",
        description="Current monitoring status message",
        default=""
    )
    
    # UI Control (from Simple Chat)
    panel_height: bpy.props.IntProperty(
        name="Panel Height",
        description="Number of response lines to display in panel",
        default=UI_SETTINGS["default_panel_height"],
        min=UI_SETTINGS["min_panel_height"],
        max=UI_SETTINGS["max_panel_height"]
    )
    
    # Internal state
    waiting_for_response: bpy.props.BoolProperty(
        name="Waiting",
        description="Currently waiting for AI response",
        default=False
    )
    
    last_seen_index: bpy.props.IntProperty(
        name="Last Seen Index",
        description="Last seen response file index",
        default=0
    )

    selected_response_file: bpy.props.StringProperty(
        name="Response File",
        description="Selected response file to display",
        default="response.txt"
    )

# Import UI and operators modules
from . import ui
from . import operators

def load_saved_settings():
    """Load saved settings and apply them"""
    try:
        settings = load_settings_from_file()
        if settings:
            # Update UI_SETTINGS with saved values
            if "panel_height" in settings:
                UI_SETTINGS["default_panel_height"] = settings["panel_height"]
            if "auto_refresh_enabled" in settings:
                UI_SETTINGS["auto_refresh_default"] = settings["auto_refresh_enabled"]
            print(f"Advanced AI: Loaded settings - {settings}")
    except Exception as e:
        print(f"Advanced AI: Failed to load settings: {e}")

def register():
    # Load saved settings first
    load_saved_settings()
    
    bpy.utils.register_class(AdvancedAIProps)
    operators.register()
    ui.register()
    
    bpy.types.WindowManager.advanced_ai_props = bpy.props.PointerProperty(type=AdvancedAIProps)
    
    print("Advanced AI Communication addon registered successfully")

def unregister():
    del bpy.types.WindowManager.advanced_ai_props
    ui.unregister()
    operators.unregister()
    bpy.utils.unregister_class(AdvancedAIProps)
    
    print("Advanced AI Communication addon unregistered")

if __name__ == "__main__":
    register()
